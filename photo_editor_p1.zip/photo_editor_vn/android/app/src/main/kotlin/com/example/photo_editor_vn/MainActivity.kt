package com.example.photo_editor_vn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
